<!DOCTYPE html>

<html>
    <head>
    <!--Settings-->
    <title>Resume Page</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
    <!--Personal styles-->
    <link href="styles.css" type="text/css" rel="stylesheet"/>
    <!--Icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
    </head>
    <body class="flex-container-column">
    <div class="header flex-item-row">
        <div class="title section">
            <h1>Davis Kieu<br/>Software Developer</h1>
            <div class="clearfix social-links">
                <ul>
                    <li><a href="https://www.linkedin.com/in/davis-kieu-ba8a6492/"><span class="fab fa-linkedin fa-2x"></span></a></li>
                    <li><a href="https://www.instagram.com/mrdaviskieu/"><span class="fab fa-instagram fa-2x"></span></a></li>
                    <li><a href="https://github.com/xthecreamx"><span class="fab fa-github-square fa-2x"></span></a></li>
                </ul>
            </div>
        </div>
        </div> 
      
    <div class="flex-item-row">  
         <div class="clearfix intro">
        <div class="clearfix img-container"><img class=" img-responsive" src="Images/daviskieu3.jpg"/>
           <div class="clearfix about section col-33">
            <div class="about panel">
            <div class="about panel-header"><h1>About Me</h1></div>
            <div class="about panel-body"><p>A	software	developer	with	4	years	of	programming	experience.	Has	extensive knowledge	of	programming	technologies	&	methodologies	and	an	effective problem-solver	that	has	a	keen	attention	to	code	and	risk	prevention.	Graduated from	Los	Angeles	Valley	College	with	Cum	Laude	and	an	expert	in	the	fabrication of	dental	products.	Adept	at	maintaining	professional	relationships,	learning	new concepts,	and	delivering	results.
</p></div>
            </div>
        </div>
        <div class="contacts section col-33">
            <div class="contacts panel">
            <div class="contacts panel-header"><h1><span class="fas fa-mail-bulk"></span> Contact Me  </h1></div>
                <div class="contacts panel-body">
                    <p class="text-center">daviskieu@rocketmail.com</p>
                </div>
        </div>
            
        </div>
        </div>
        </div>
          <div class="content clearfix">
                <div class="skills section col-33">
                    <div class="skills panel">
                        <div class="skills panel-header"><h2>Skills</h2></div>
                        <div class="skills panel-body">
                        <ol>
                            <li>
                             <div class="entry">
                            <h4>Soft Skills</h4>
                            <ol>
                                <li>Teamwork</li>
                                <li>Communications</li>
                                <li>Problem Solving</li>
                                <li>Logical Analysis</li>
                                <li>Time Management</li>
                            </ol>
                            </div>
                            </li>
                            <li>
                            <div class="entry">
                            <h4>Hard Skills</h4>
                              <ol>
                                <li>HTML 5 , CSS 3 , JS</li>
                                <li>Java , C# , C++ </li>
                                <li>MYSQL , MS SERVER</li>
                                <li>PHP 5</li>
                            </ol>
                            </div>
                            </li>
                            <li>
                            <div class="entry">
                            <h4>Software Skills</h4>
                            <ol>
                                <li>Eclipse IDE</li>
                                <li>Visual Studio IDE</li>
                                <li>Microsoft Suite</li>
                                <li>UML</li>
                            </ol>
                            </div>
                            </li>
                        </ol>
                    </div>
              </div>
              </div>
                <div class="education section col-33">
                    <div class="education panel">
                        <div class="education panel-header"><h2>Education</h2></div>
                        <div class="education panel-body">
                        <ol>
                            <li>
                             <div class="entry">
                            <h4>Francis Polytechnic Highschool , General Studies</h4>
                            <p>Honors</p>
                            </div>
                            </li>
                            <li>
                            <div class="entry">
                            <h4>Los Angeles Valley College , AS , Computer Science</h4>
                            <p>Cum Laude</p>
                            </div>
                            </li>
                        </ol>
                        </div>
                    </div>
              </div>
                <div class="experience section col-33">
                    <div class="experience panel">
                        <div class="experience panel-header"><h2>Experience</h2>
                        </div>
                        <div class="experience panel-body">
                         <ol>
                            <li>
                            <div class="entry">
                            <h4>Burbank Dental Labs , Dental Technician</h4>
                            <p>My	daily	tasks	were	to	handle	dental	impressions	and	follow	RX	instructions	to produce	quality	model	work	for	Crown	&	Bridge	production.</p>
                            </div>
                            </li>
                            <li>
                             <div class="entry">
                            <h4>Precision Orthodontic Labs , Dental Technician</h4>
                            <p>My	daily	tasks	were	to	create	Orthodontic	appliances	for	Orthodontists.	I	followed instructions	specified	on	RX’s	and	produced	quality	products	under	ISO Standards.</p>
                            </div>
                            </li>
                        </ol>
                        </div>
                    </div>
              </div>
            </div>
    </div>
    <div class="clearfix footer flex-item-row">
        <div class="copyright col-50">
            <p><span class="far fa-copyright"></span> Copyright <?php echo date('Y');?> | Davis Kieu</p>
        </div>
        <div class="downloads col-50">
            <a class="clearfix" download="Davis+Resume" href="downloads/Davis_Resume_2019_Update.pdf"><span class="fas fa-download fa-lg"></span> Download Physical Resume</a>
        </div>


    </div>
    <!--Load JQuery-->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script>
        $(function(){
        var $header = $('div.header').hide();
        var $intro = $('div.intro').hide();
        var $content_panels = $('div.content').find('div.panel').hide();
        var $footer = $('div.footer').hide();
            
            $header.delay(500).fadeIn(500,function(){
                $panels = $intro.find('div.panel').hide();
                $intro.delay(300).fadeIn(500,function(){ $panels.each(function(index){ $(this).delay(200*index).slideDown(500,function(){
                  $content_panels.each(function(index){
                      $(this).delay(200*index).fadeIn(200,function(){$footer.delay(300).fadeIn(200);});
                  });
                });});});
            });
            
        
        });
       
        
    </script>
    </body>
</html>